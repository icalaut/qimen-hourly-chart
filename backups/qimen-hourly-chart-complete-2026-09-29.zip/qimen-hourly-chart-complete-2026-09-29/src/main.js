const PALACES = [
  { number: '4', name: '巽宫', direction: '东南' },
  { number: '9', name: '离宫', direction: '南' },
  { number: '2', name: '坤宫', direction: '西南' },
  { number: '3', name: '震宫', direction: '东' },
  { number: '5', name: '中宫', direction: '中' },
  { number: '7', name: '兑宫', direction: '西' },
  { number: '8', name: '艮宫', direction: '东北' },
  { number: '1', name: '坎宫', direction: '北' },
  { number: '6', name: '乾宫', direction: '西北' },
];

const BRANCHES = [
  ['子', 0], ['丑', 1], ['寅', 3], ['卯', 5], ['辰', 7], ['巳', 9],
  ['午', 11], ['未', 13], ['申', 15], ['酉', 17], ['戌', 19], ['亥', 21],
];

const dateInput = document.querySelector('#chart-date');
const hourInput = document.querySelector('#chart-hour');
const methodInput = document.querySelector('#ju-method');
const ziMethodInput = document.querySelector('#zi-method');
const chartTypeInput = document.querySelector('#chart-type');
const sevenStarInput = document.querySelector('#seven-star-toggle');
const travelInput = document.querySelector('#travel-toggle');
const personalThreeVictoryInput = document.querySelector('#personal-three-victory-toggle');
const travelMonthInput = document.querySelector('#travel-month');
const shiftInput = document.querySelector('#shift-toggle');
const shiftStepsInput = document.querySelector('#shift-steps');
const previousShiftButton = document.querySelector('#previous-shift-button');
const nextShiftButton = document.querySelector('#next-shift-button');
const shiftStepStatus = document.querySelector('#shift-step-status');
const form = document.querySelector('#chart-form');
const result = document.querySelector('#result');
const emptyState = document.querySelector('#empty-state');
const errorMessage = document.querySelector('#error-message');
const engineStatus = document.querySelector('#engine-status');
const TRADITIONAL_TO_SIMPLIFIED = {
  陰: '阴', 陽: '阳', 補: '补', 頭: '头', 節: '节', 氣: '气', 時: '时', 門: '门',
  輔: '辅', 騰: '腾', 沖: '冲', 傷: '伤', 驚: '惊', 離: '离', 兌: '兑', 宮: '宫', 開: '开', 儀: '仪', 擊: '击',
};
const LAYER_ENGINE_URL = 'https://esm.sh/bigfishmarquis-qimen@1.0.0/src/engine.ts?bundle';
const LUNAR_ENGINE_URL = 'https://esm.sh/lunar-javascript@1.7.7?bundle';
const OPENCC_URL = 'https://esm.sh/opencc-js@1.4.2/cn2t';
const STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
const CYCLE_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
const GANZHI_CYCLE = Array.from({ length: 60 }, (_, index) => `${STEMS[index % 10]}${CYCLE_BRANCHES[index % 12]}`);
const LUO_SHU_FLIGHT_ORDER = [4, 8, 5, 6, 1, 7, 2, 3, 0];
const FLYING_STAR_NAMES = ['', '一白', '二黑', '三碧', '四綠', '五黃', '六白', '七赤', '八白', '九紫'];
const DAY_STAR_ANCHORS = [
  { term: '冬至', center: 1, direction: 1 },
  { term: '雨水', center: 7, direction: 1 },
  { term: '谷雨', center: 4, direction: 1 },
  { term: '夏至', center: 9, direction: -1 },
  { term: '处暑', center: 3, direction: -1 },
  { term: '霜降', center: 6, direction: -1 },
];
const DAY_BRANCH_GROUPS = {
  子午卯酉: new Set(['子', '午', '卯', '酉']),
  辰戌丑未: new Set(['辰', '戌', '丑', '未']),
  寅申巳亥: new Set(['寅', '申', '巳', '亥']),
};
const XUN_FU_SHOU = { 甲子: '戊', 甲戌: '己', 甲申: '庚', 甲午: '辛', 甲辰: '壬', 甲寅: '癸' };
const PALACE_NAMES = { 1: '坎', 2: '坤', 3: '震', 4: '巽', 5: '中', 6: '乾', 7: '兑', 8: '艮', 9: '离' };
const SHIFT_RING = [7, 6, 3, 0, 1, 2, 5, 8];
const VOID_BRANCH_PALACES = { 子: 1, 丑: 8, 寅: 8, 卯: 3, 辰: 4, 巳: 4, 午: 9, 未: 2, 申: 2, 酉: 7, 戌: 6, 亥: 6 };
const YIMA_BRANCHES = {
  子: '寅', 辰: '寅', 申: '寅',
  寅: '申', 午: '申', 戌: '申',
  巳: '亥', 酉: '亥', 丑: '亥',
  亥: '巳', 卯: '巳', 未: '巳',
};
const OVERALL_PATTERN_NAMES = new Set(['反吟', '伏吟', '五不遇時', '截路空亡']);
const TIME_ONLY_PATTERN_NAMES = new Set(['五不遇時', '截路空亡']);
const STAR_HOME_POSITIONS = { 天蓬: 1, 天芮: 2, 天冲: 3, 天辅: 4, 天禽: 5, 天心: 6, 天柱: 7, 天任: 8, 天英: 9 };
const DOOR_HOME_POSITIONS = { 休门: 1, 生门: 8, 伤门: 3, 杜门: 4, 景门: 9, 死门: 2, 惊门: 7, 开门: 6 };
const STEM_TOMB_PALACES = { 乙: 6, 丙: 6, 丁: 8, 戊: 6, 己: 8, 庚: 8, 辛: 4, 壬: 4, 癸: 2 };
const MODE_HINTS = {
  mingpan: '按所填出生年月日时，以时家转盘法起个人命盘。',
  nianjia: '年家盘按所选公历年份起局；月、日、时不参与年盘计算。',
  yuejia: '月家盘按所选日期对应的节气月起局；时刻用于判定节气月。',
  rijia: '日家盘按所选公历年月日起局；小时不参与日盘计算。',
  shijia: '时家盘按所选日期与整点时辰起局。',
};
function shiftStepLabel(steps) {
  return Number(steps) === 0 ? '原位' : `顺移${steps}宫`;
}
let layerEnginePromise;
let lunarEnginePromise;
let traditionalizerPromise;
let hasGeneratedNatalChart = false;
let traditionalize = (value) => String(value ?? '—');

function pad(value) {
  return String(value).padStart(2, '0');
}

async function formatLunarDate(datetime, chart) {
  lunarEnginePromise ||= import(LUNAR_ENGINE_URL);
  const { Solar } = await lunarEnginePromise;
  const year = Number(datetime.slice(0, 4));
  const month = Number(datetime.slice(4, 6));
  const day = Number(datetime.slice(6, 8));
  const lunarDate = Solar.fromYmd(year, month, day).getLunar().toString();
  const includesHour = ['命盘', '月盘', '时盘'].includes(chart.盤型);
  const hourBranch = chart.時柱?.[1] || branchForHour(Number(datetime.slice(8, 10)));
  return traditionalize(`农历${lunarDate}日${includesHour && hourBranch ? ` · ${hourBranch}时` : ''}`);
}

function simplify(value) {
  return String(value ?? '—').replace(/[陰陽補頭節氣時門輔騰沖傷驚離兌宮開儀擊]/g, (char) => TRADITIONAL_TO_SIMPLIFIED[char]);
}

function convertStaticInterface() {
  document.documentElement.lang = 'zh-TW';
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (!node.parentElement?.closest('script, style')) node.nodeValue = traditionalize(node.nodeValue);
  }
  document.querySelectorAll('[aria-label], [title], [placeholder]').forEach((element) => {
    for (const attribute of ['aria-label', 'title', 'placeholder']) {
      if (element.hasAttribute(attribute)) element.setAttribute(attribute, traditionalize(element.getAttribute(attribute)));
    }
  });
  document.title = traditionalize(document.title);
}

function loadTraditionalizer() {
  traditionalizerPromise ||= import(OPENCC_URL).then(({ Converter }) => {
    const convert = Converter({ from: 'cn', to: 'tw' });
    traditionalize = (value) => convert(String(value ?? '—')).replaceAll('醜時', '丑時');
    convertStaticInterface();
    updateChartTypeControls();
  }).catch((error) => {
    console.error('繁體轉換器載入失敗', error);
  });
  return traditionalizerPromise;
}

function branchForHour(hour) {
  if (hour === 23) return '子';
  const branch = BRANCHES.find(([, start], index) => {
    const end = BRANCHES[index + 1]?.[1] ?? 23;
    return hour >= start && hour < end;
  });
  return branch?.[0] ?? '子';
}

function hourLabel(hour) {
  const branch = branchForHour(hour);
  return traditionalize(`${pad(hour)}:00 · ${branch}时`);
}

function setDefaults() {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date()).map(({ type, value }) => [type, value]));
  dateInput.value = `${parts.year}-${parts.month}-${parts.day}`;
  hourInput.value = String(Number(parts.hour));
}

function setSelectedDateOffset(dayOffset) {
  if (!dateInput.value) return false;
  const [year, month, day] = dateInput.value.split('-').map(Number);
  const shiftedDate = new Date(Date.UTC(year, month - 1, day + dayOffset));
  dateInput.value = `${shiftedDate.getUTCFullYear()}-${pad(shiftedDate.getUTCMonth() + 1)}-${pad(shiftedDate.getUTCDate())}`;
  return true;
}

function shiftSelectedDate(dayOffset) {
  if (!setSelectedDateOffset(dayOffset)) return;
  generateChart();
}

function populateHours() {
  for (let hour = 0; hour < 24; hour += 1) {
    const option = document.createElement('option');
    option.value = String(hour);
    option.textContent = hourLabel(hour);
    hourInput.append(option);
  }
}

function makePillar(label, value) {
  const item = document.createElement('div');
  item.className = 'pillar';
  const title = document.createElement('span');
  title.className = 'pillar-label';
  title.textContent = traditionalize(label);
  const stem = document.createElement('span');
  stem.className = 'pillar-value';
  const characters = [...traditionalize(value)];
  if (characters.length === 2) {
    stem.classList.add('pillar-value-vertical');
    characters.forEach((character) => {
      const line = document.createElement('span');
      line.textContent = character;
      stem.append(line);
    });
  } else {
    stem.textContent = characters.join('');
  }
  item.append(title, stem);
  return item;
}

function formatTianYi(star, palaceNumber) {
  const palace = PALACES.find((item) => Number(item.number) === Number(palaceNumber));
  if (!star || !palace) return '—';
  return traditionalize(`${star} · ${palace.direction}${palace.name}`);
}

function calculateHourlyTianYi(chart) {
  const hourStem = chart['時柱']?.[0] === '甲' ? chart['符首'] : chart['時柱']?.[0];
  const earthIndex = chart['地盤']?.indexOf(hourStem) ?? -1;
  if (earthIndex < 0) return '—';

  const originalPosition = Number(PALACES[earthIndex]?.number);
  const originalStars = { 1: '天蓬', 2: '天芮', 3: '天冲', 4: '天辅', 5: '天禽', 6: '天心', 7: '天柱', 8: '天任', 9: '天英' };
  const star = originalStars[originalPosition];
  const searchStar = star === '天禽' ? '天芮' : star;
  const starIndex = chart['九星']?.findIndex((starName) => simplify(starName) === searchStar) ?? -1;
  const landedPalace = PALACES[starIndex];
  if (!star || !landedPalace) return '—';
  return `${star} · ${landedPalace.direction}${landedPalace.name}`;
}

function hasOppositeLayer(chart, field, homePositions) {
  const outerPalaces = PALACES.flatMap((palace, index) => {
    const palaceNumber = Number(palace.number);
    if (palaceNumber === 5) return [];
    return [{ palaceNumber, item: simplify(chart[field]?.[index]) }];
  });
  return outerPalaces.length === 8 && outerPalaces.every(({ palaceNumber, item }) => (
    homePositions[item] !== undefined && palaceNumber === 10 - homePositions[item]
  ));
}

function getOverallFormations(chart, includesHour = true) {
  const formations = window.Qimen.detectPatterns(chart)
    .filter((item) => item.類 === '格局'
      && (!item.宮 || OVERALL_PATTERN_NAMES.has(item.格))
      && (includesHour || !TIME_ONLY_PATTERN_NAMES.has(item.格)))
    .map((item) => OVERALL_PATTERN_NAMES.has(item.格) ? { ...item, 宮: null } : item);

  const reverseLayers = [
    hasOppositeLayer(chart, '九星', STAR_HOME_POSITIONS) && '九星',
    hasOppositeLayer(chart, '天門', DOOR_HOME_POSITIONS) && '八门',
  ].filter(Boolean);
  if (reverseLayers.length > 0) {
    const existingFanYin = formations.find((item) => item.格 === '反吟');
    const fanYin = existingFanYin || { 類: '格局', 格: '反吟', 吉凶: '凶', 宮: null };
    fanYin.宮 = null;
    fanYin.讀法 = `${reverseLayers.join('、')}反吟`;
    fanYin.細節 = `${reverseLayers.join('与')}整层均落在各自本位宫的对宫`;
    if (!existingFanYin) formations.push(fanYin);
  }

  const hasFanYin = formations.some((item) => item.格 === '反吟');
  const hasFuYin = formations.some((item) => item.格 === '伏吟');
  if (hasFanYin && hasFuYin) {
    formations.push({ 類: '格局', 格: '反吟伏吟', 吉凶: '凶', 宮: null, 細節: '本盘同时符合反吟与伏吟条件' });
  }

  const zhiShiPosition = chart['天門']?.findIndex((door) => door === chart['值使']) ?? -1;
  if (zhiShiPosition >= 0 && chart['地盤']?.[zhiShiPosition] === '丁') {
    formations.push({
      類: '格局',
      格: '玉女守门',
      讀法: '玉女时',
      吉凶: '吉',
      宮: null,
      細節: `值使门${chart['值使']}临地盘丁，玉女守门`,
    });
  }

  return formations;
}

function makeLayerChart(source, type, timeChart) {
  const config = {
    nianjia: { label: '年盘', pillar: 'year' },
    yuejia: { label: '月盘', pillar: 'month' },
    rijia: { label: '日盘', pillar: 'day' },
  }[type];
  const palaceByNumber = new Map(source.palaces.map((palace) => [palace.palaceNumber, palace]));
  const orderedPalaces = PALACES.map(({ number }) => palaceByNumber.get(Number(number)));
  const activePillar = source.fourPillars[config.pillar];
  const activeGanzhi = `${activePillar.gan || ''}${activePillar.zhi || ''}`;
  const cycleIndex = GANZHI_CYCLE.indexOf(activeGanzhi);
  if (cycleIndex < 0) throw new Error(`无法从${config.label}计算旬首：${activeGanzhi || '缺少干支'}`);

  const xunHead = GANZHI_CYCLE[Math.floor(cycleIndex / 10) * 10];
  const pillarText = (pillar) => `${pillar.gan || ''}${pillar.zhi || ''}` || '—';
  const palaceLabel = (number) => `${PALACE_NAMES[number] || ''}宫`;
  const yuan = { 上: '上元', 中: '中元', 下: '下元' }[source.yuan] || '—';

  const chart = {
    盤型: config.label,
    展示說明: `${config.label}使用对应的独立排盘算法。`,
    年柱: pillarText(source.fourPillars.year),
    月柱: pillarText(source.fourPillars.month),
    日柱: pillarText(source.fourPillars.day),
    時柱: pillarText(source.fourPillars.hour),
    時干: source.fourPillars.hour.gan || '',
    陰陽: source.dun === 'yang' ? '陽' : '陰',
    局數: source.juNumber,
    節氣: timeChart.節氣,
    三元: yuan,
    旬首: xunHead,
    符首: XUN_FU_SHOU[xunHead],
    值符: source.zhiFuStar,
    值符落宮: palaceLabel(source.zhiFuPalace),
    值使: source.zhiShiDoor,
    值使落宮: palaceLabel(source.zhiShiPalace),
    天乙: formatTianYi(source.tianYiStar, source.tianYiPalace),
    八神: orderedPalaces.map((palace) => palace?.god || '—'),
    九星: orderedPalaces.map((palace) => palace?.star || '—'),
    天門: orderedPalaces.map((palace) => palace?.door || '—'),
    天盤: orderedPalaces.map((palace) => palace?.earthStem || '—'),
    地盤: orderedPalaces.map((palace) => palace?.skyStem || '—'),
  };
  chart.格局列表 = getOverallFormations(chart, false);
  return chart;
}

async function generateFlightCharts(datetime) {
  const timeChart = window.Qimen.chartToObject(window.Qimen.generateChartByDatetime(datetime, {
    定局法: methodInput.value,
    夜子時: ziMethodInput.value,
  }));
  lunarEnginePromise ||= import(LUNAR_ENGINE_URL);
  const { Solar } = await lunarEnginePromise;
  const year = Number(datetime.slice(0, 4));
  const month = Number(datetime.slice(4, 6));
  const day = Number(datetime.slice(6, 8));
  const hour = Number(datetime.slice(8, 10));
  const solarYear = resolveSolarYear(year, timeChart['年柱']);
  const yearBranch = timeChart['年柱']?.[1];
  const monthBranch = timeChart['月柱']?.[1];
  const dayPillar = timeChart['日柱'] || '';
  const dayBranch = dayPillar[1];
  const hourBranch = timeChart['時柱']?.[1];
  const monthIndex = { 寅: 0, 卯: 1, 辰: 2, 巳: 3, 午: 4, 未: 5, 申: 6, 酉: 7, 戌: 8, 亥: 9, 子: 10, 丑: 11 }[monthBranch];
  const monthStart = getGroupedStar(yearBranch, { 子午卯酉: 8, 寅申巳亥: 2, 辰戌丑未: 5 });
  const daily = getDailyFlyingStar(Solar, year, month, day, dayPillar);
  const seasonalDirection = getSeasonalDirection(Solar, year, month, day, hour);
  const hourIndex = CYCLE_BRANCHES.indexOf(hourBranch);
  const hourStart = getGroupedStar(dayBranch, seasonalDirection === 1
    ? { 子午卯酉: 1, 辰戌丑未: 4, 寅申巳亥: 7 }
    : { 子午卯酉: 9, 辰戌丑未: 3, 寅申巳亥: 6 });

  if (monthIndex === undefined || hourIndex < 0) throw new Error('無法根據干支確定月或時飛星。');

  return [
    makeFlyingStarChart('年飛星', normalizeFlyingStar(11 - String(solarYear).split('').reduce((sum, digit) => sum + Number(digit), 0)), 1),
    makeFlyingStarChart('月飛星', normalizeFlyingStar(monthStart - monthIndex), 1),
    makeFlyingStarChart('日飛星', daily.center, daily.direction),
    makeFlyingStarChart('時飛星', normalizeFlyingStar(hourStart + seasonalDirection * hourIndex), seasonalDirection),
  ];
}

function normalizeFlyingStar(number) {
  return ((number - 1) % 9 + 9) % 9 + 1;
}

function getGroupedStar(branch, groups) {
  const group = Object.entries(DAY_BRANCH_GROUPS).find(([, branches]) => branches.has(branch));
  const star = groups[group?.[0]];
  if (!star) throw new Error(`無法根據地支確定紫白星：${branch || '缺少地支'}`);
  return star;
}

function makeFlyingStarChart(label, center, direction) {
  const stars = Array(9);
  LUO_SHU_FLIGHT_ORDER.forEach((palaceIndex, step) => {
    stars[palaceIndex] = normalizeFlyingStar(center + direction * step);
  });
  return {
    盤型: label,
    中宮: center,
    飛向: direction === 1 ? '順飛' : '逆飛',
    九宮星: stars,
  };
}

function civilTimestamp(year, month, day, hour = 0, minute = 0, second = 0) {
  return Date.UTC(year, month - 1, day, hour, minute, second);
}

function solarTimestamp(solar) {
  return civilTimestamp(solar.getYear(), solar.getMonth(), solar.getDay(), solar.getHour(), solar.getMinute(), solar.getSecond());
}

function getSolarTermEntries(Solar, years) {
  const entries = new Map();
  years.forEach((year) => {
    const table = Solar.fromYmd(year, 6, 21).getLunar().getJieQiTable();
    DAY_STAR_ANCHORS.forEach(({ term, center, direction }) => {
      const solar = table[term];
      if (solar) entries.set(`${term}-${solarTimestamp(solar)}`, { term, center, direction, timestamp: solarTimestamp(solar) });
    });
  });
  return [...entries.values()];
}

function getDailyFlyingStar(Solar, year, month, day, dayPillar) {
  const dayCycleIndex = GANZHI_CYCLE.indexOf(dayPillar);
  if (dayCycleIndex < 0) throw new Error(`無法根據日柱確定日紫白：${dayPillar || '缺少日柱'}`);

  const calendarDate = Solar.fromYmd(year, month, day);
  const calendarCycleIndex = GANZHI_CYCLE.indexOf(calendarDate.getLunar().getDayInGanZhi());
  const dayOffset = ((dayCycleIndex - calendarCycleIndex) % 60 + 60) % 60;
  const effectiveTimestamp = civilTimestamp(year, month, day + (dayOffset === 1 ? 1 : 0));
  const terms = getSolarTermEntries(Solar, [year - 1, year, year + 1]);
  const anchors = terms.map((entry) => {
    const termDate = new Date(entry.timestamp);
    const termSolar = Solar.fromYmd(termDate.getUTCFullYear(), termDate.getUTCMonth() + 1, termDate.getUTCDate());
    const termCycleIndex = GANZHI_CYCLE.indexOf(termSolar.getLunar().getDayInGanZhi());
    const daysToJiazi = (60 - termCycleIndex) % 60;
    const termDay = civilTimestamp(termDate.getUTCFullYear(), termDate.getUTCMonth() + 1, termDate.getUTCDate());
    return { ...entry, anchorTimestamp: termDay + daysToJiazi * 86400000 };
  }).filter((entry) => entry.anchorTimestamp <= effectiveTimestamp)
    .sort((first, second) => first.anchorTimestamp - second.anchorTimestamp || first.timestamp - second.timestamp);
  const anchor = anchors.at(-1);
  if (!anchor) throw new Error('無法找到所選日期之前的日紫白甲子錨點。');

  const elapsedDays = Math.floor((effectiveTimestamp - anchor.anchorTimestamp) / 86400000);
  return {
    center: normalizeFlyingStar(anchor.center + anchor.direction * elapsedDays),
    direction: anchor.direction,
  };
}

function getSeasonalDirection(Solar, year, month, day, hour) {
  const timestamp = civilTimestamp(year, month, day, hour);
  const solstices = getSolarTermEntries(Solar, [year - 1, year, year + 1])
    .filter(({ term }) => term === '冬至' || term === '夏至')
    .filter(({ timestamp: termTimestamp }) => termTimestamp <= timestamp)
    .sort((first, second) => first.timestamp - second.timestamp);
  const latestSolstice = solstices.at(-1);
  if (!latestSolstice) throw new Error('無法判定時紫白的冬夏順逆。');
  return latestSolstice.term === '冬至' ? 1 : -1;
}

function resolveSolarYear(calendarYear, yearPillar) {
  const solarYear = [calendarYear - 1, calendarYear, calendarYear + 1].find((candidate) => {
    const cycleIndex = ((candidate - 4) % 60 + 60) % 60;
    return GANZHI_CYCLE[cycleIndex] === yearPillar;
  });
  if (!solarYear) throw new Error(`无法根据年柱确定立春年：${yearPillar}`);
  return solarYear;
}

async function generateByChartType(type, datetime) {
  const timeChart = window.Qimen.chartToObject(window.Qimen.generateChartByDatetime(datetime, {
    定局法: methodInput.value,
    夜子時: ziMethodInput.value,
  }));

  if (type === 'shijia') {
    return {
      ...timeChart,
      盤型: '时盘',
      天乙: calculateHourlyTianYi(timeChart),
      格局列表: getOverallFormations(timeChart),
    };
  }
  if (type === 'mingpan') {
    const shiftedChart = shiftInput.checked ? applyStarShift(timeChart, Number(shiftStepsInput.value)) : timeChart;
    return {
      ...shiftedChart,
      盤型: '命盘',
      天乙: calculateHourlyTianYi(shiftedChart),
      格局列表: getOverallFormations(shiftedChart),
      展示說明: `个人命盘按所填出生时刻，以时家转盘法生成${shiftInput.checked ? `，${shiftStepLabel(shiftStepsInput.value)}` : ''}。`,
      移星換斗對照: shiftInput.checked ? { before: timeChart, after: shiftedChart } : null,
    };
  }

  layerEnginePromise ||= import(LAYER_ENGINE_URL);
  const layerEngine = await layerEnginePromise;
  const year = Number(datetime.slice(0, 4));
  const solarYear = resolveSolarYear(year, timeChart['年柱']);
  const month = Number(datetime.slice(4, 6));
  const day = Number(datetime.slice(6, 8));
  let chart;

  if (type === 'nianjia') {
    chart = layerEngine.nianJiaGenerate(solarYear);
  } else if (type === 'yuejia') {
    const monthBranch = timeChart['月柱']?.[1];
    const termMonth = { 寅: 1, 卯: 2, 辰: 3, 巳: 4, 午: 5, 未: 6, 申: 7, 酉: 8, 戌: 9, 亥: 10, 子: 11, 丑: 12 }[monthBranch];
    if (!termMonth) throw new Error('无法根据节气月确定月家盘。');
    chart = layerEngine.yueJiaGenerate(solarYear, termMonth);
  } else {
    chart = layerEngine.riJiaGenerate(year, month, day);
  }

  return makeLayerChart(chart, type, timeChart);
}

function applyStarShift(chart, steps) {
  const normalizedSteps = ((steps % SHIFT_RING.length) + SHIFT_RING.length) % SHIFT_RING.length;
  if (normalizedSteps === 0) return chart;

  const shifted = { ...chart };
  const layerFields = ['八神', '九星', '天門', '天盤', '地盤'];
  layerFields.forEach((field) => {
    if (!Array.isArray(chart[field]) || chart[field].length !== PALACES.length) return;
    const layer = [...chart[field]];
    const nextLayer = [...layer];
    SHIFT_RING.forEach((sourcePosition, ringIndex) => {
      const targetPosition = SHIFT_RING[(ringIndex + normalizedSteps) % SHIFT_RING.length];
      nextLayer[targetPosition] = layer[sourcePosition];
    });
    shifted[field] = nextLayer;
  });
  return shifted;
}

function updateChartTypeControls() {
  const type = chartTypeInput.value;
  const needsHour = ['mingpan', 'yuejia', 'shijia'].includes(type);
  const usesHourlyEngine = ['mingpan', 'shijia'].includes(type);
  const usesMonthlyScan = travelInput.checked || personalThreeVictoryInput.checked;
  document.querySelector('#seven-star-option').hidden = type !== 'shijia';
  document.querySelector('#seven-star-objectives').hidden = type !== 'shijia' || !sevenStarInput.checked;
  document.querySelector('#travel-option').hidden = type !== 'mingpan';
  document.querySelector('#personal-three-victory-option').hidden = type !== 'mingpan';
  document.querySelector('#travel-month-option').hidden = type !== 'mingpan' || !usesMonthlyScan;
  document.querySelector('#shift-option').hidden = type !== 'mingpan';
  document.querySelector('#shift-settings').hidden = type !== 'mingpan' || !shiftInput.checked;
  travelInput.disabled = type !== 'mingpan';
  personalThreeVictoryInput.disabled = type !== 'mingpan';
  sevenStarInput.disabled = type !== 'shijia';
  shiftInput.disabled = type !== 'mingpan';
  travelMonthInput.disabled = !(type === 'mingpan' && usesMonthlyScan && hasGeneratedNatalChart);
  const canShift = type === 'mingpan' && hasGeneratedNatalChart;
  previousShiftButton.disabled = !canShift;
  nextShiftButton.disabled = !canShift;
  shiftStepsInput.disabled = !canShift;
  shiftStepStatus.textContent = traditionalize(canShift ? shiftStepLabel(shiftStepsInput.value) : '尚未生成命盘');
  document.querySelector('#mode-hint').textContent = traditionalize(MODE_HINTS[type]);
  document.querySelector('.field-heading').hidden = !needsHour;
  document.querySelector('.time-input-row').hidden = !needsHour;
  hourInput.disabled = !needsHour;
  document.querySelector('#previous-shichen-button').hidden = !needsHour;
  document.querySelector('#next-shichen-button').hidden = !needsHour;
  document.querySelector('#ju-method-label').hidden = !usesHourlyEngine;
  methodInput.hidden = !usesHourlyEngine;
  document.querySelector('label[for="zi-method"]').hidden = !usesHourlyEngine;
  ziMethodInput.hidden = !usesHourlyEngine;
}

function renderTravelMonth(monthValue, matches, mode = 'travel') {
  const section = document.querySelector('#travel-month-section');
  const container = document.querySelector('#travel-month-results');
  if (!monthValue) {
    section.hidden = true;
    container.replaceChildren();
    return;
  }

  const [year, month] = monthValue.split('-').map(Number);
  const isPersonalThreeVictory = mode === 'personalThreeVictory';
  document.querySelector('#travel-month-title').textContent = traditionalize(isPersonalThreeVictory ? '个人三胜宫' : '出行诀');
  document.querySelector('.travel-month-note').textContent = traditionalize(
    isPersonalThreeVictory
      ? '以本命值符、九天、生门三宫为个人目标，叠合月盘、日盘与时盘；方向按目标宫背向。'
      : '本命盘定目标宫，月家盘、日家盘和时家盘逐层筛选；每天按十二个两小时段计算。',
  );
  document.querySelector('#travel-month-summary').textContent = traditionalize(`${year} 年 ${month} 月 · ${matches.length} 天`);
  section.hidden = false;

  if (matches.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'travel-month-empty';
    empty.textContent = traditionalize(isPersonalThreeVictory
      ? '本月没有符合个人三胜宫叠盘条件的日期。'
      : '本月没有符合天月值符日、九天日或生门日条件的日期。');
    container.replaceChildren(empty);
    return;
  }

  const table = document.createElement('table');
  table.className = 'travel-month-table';
  table.setAttribute('aria-label', traditionalize(isPersonalThreeVictory ? '整月个人三胜宫日期与时段' : '整月出行诀日期与时段'));
  const header = document.createElement('tr');
  ['日期', '天月值符日', '九天日', '生门日'].forEach((heading) => {
    const cell = document.createElement('th');
    cell.scope = 'col';
    cell.textContent = traditionalize(heading);
    header.append(cell);
  });
  const head = document.createElement('thead');
  head.append(header);

  const body = document.createElement('tbody');
  matches.forEach(({ day, weekday, categories }) => {
    const row = document.createElement('tr');
    const dateCell = document.createElement('td');
    const date = document.createElement('time');
    date.dateTime = `${year}-${pad(month)}-${pad(day)}T00:00:00+08:00`;
    date.textContent = traditionalize(`${pad(month)}/${pad(day)} 周${weekday}`);
    dateCell.append(date);
    row.append(dateCell);

    categories.forEach(({ matches: categoryMatches, targetIndex, detail, hours, calendarLabel }) => {
      const cell = document.createElement('td');
      cell.className = 'travel-category-cell';
      const palace = PALACES[targetIndex];
      if (categoryMatches) {
        const label = document.createElement('span');
        label.className = 'travel-calendar-label';
        label.textContent = traditionalize(calendarLabel);
        const direction = document.createElement('strong');
        direction.className = 'travel-direction';
        direction.textContent = traditionalize(palace.number === '5' ? palace.name : `${palace.direction}${palace.name}`);
        const hoursLabel = document.createElement('span');
        hoursLabel.className = 'travel-hours';
        hoursLabel.textContent = traditionalize(hours.join('、'));
        cell.append(label, direction, hoursLabel);
        cell.title = traditionalize(`${palace.direction}${palace.name}：${detail}`);
      } else {
        cell.classList.add('is-empty');
        cell.textContent = '—';
      }
      row.append(cell);
    });
    body.append(row);
  });

  table.append(head, body);
  const tableWrap = document.createElement('div');
  tableWrap.className = 'travel-month-table-wrap';
  tableWrap.append(table);
  container.replaceChildren(tableWrap);
}

function renderSevenStarLamp(chart) {
  const section = document.querySelector('#seven-star-section');
  const container = document.querySelector('#seven-star-results');
  if (!sevenStarInput.checked || chart.盤型 !== '时盘') {
    section.hidden = true;
    container.replaceChildren();
    return;
  }

  const palaceLabel = (index) => {
    const palace = PALACES[index];
    return palace ? traditionalize(palace.number === '5' ? palace.name : `${palace.direction}${palace.name}`) : '—';
  };
  const findDoor = (door) => findPalaceIndex(chart, '天門', door);
  const findGod = (god) => findPalaceIndex(chart, '八神', god);
  const findStar = (star) => findPalaceIndex(chart, '九星', star);
  const deadIndex = findDoor('死门');
  const lifeIndex = findDoor('生门');
  const sevenStarMap = [
    ['天枢 · 贪狼', '天蓬'],
    ['天璇 · 巨门', '天芮'],
    ['天玑 · 禄存', '天冲'],
    ['天权 · 文曲', '天辅'],
    ['玉衡 · 廉贞', '天禽'],
    ['开阳 · 武曲', '天心'],
    ['摇光 · 破军', '天柱'],
  ];

  document.querySelector('#seven-star-summary').textContent = traditionalize(
    `死门 ${palaceLabel(deadIndex)} → 生门 ${palaceLabel(lifeIndex)}`,
  );
  section.hidden = false;
  container.replaceChildren();

  const table = document.createElement('table');
  table.className = 'seven-star-table';
  table.setAttribute('aria-label', traditionalize('七星灯对应宫位'));
  const headRow = document.createElement('tr');
  ['星灯', '奇门九星', '当前宫位'].forEach((heading) => {
    const cell = document.createElement('th');
    cell.scope = 'col';
    cell.textContent = traditionalize(heading);
    headRow.append(cell);
  });
  const head = document.createElement('thead');
  head.append(headRow);
  const body = document.createElement('tbody');
  sevenStarMap.forEach(([lamp, star]) => {
    const row = document.createElement('tr');
    const lampCell = document.createElement('td');
    lampCell.textContent = traditionalize(lamp);
    const starCell = document.createElement('td');
    starCell.textContent = traditionalize(star);
    const palaceCell = document.createElement('td');
    palaceCell.textContent = palaceLabel(findStar(star));
    row.append(lampCell, starCell, palaceCell);
    body.append(row);
  });
  table.append(head, body);
  container.append(table);

  const selectedObjectives = new Set([...document.querySelectorAll('input[name="sevenStarObjective"]:checked')].map((input) => input.value));
  const objectiveCandidates = {
    longevity: getSevenStarObjectiveCandidates(chart, 'longevity'),
    career: getSevenStarObjectiveCandidates(chart, 'career'),
    wealth: getSevenStarObjectiveCandidates(chart, 'wealth'),
  };
  const candidateLabels = (candidates) => candidates.map(({ index }) => palaceLabel(index)).join('、');
  const candidateFormations = (candidates) => [...new Set(candidates.flatMap(({ formations }) => formations))].join('、');
  const cards = document.createElement('div');
  cards.className = 'seven-star-cards';
  const addCard = (label, value, detail) => {
    const card = document.createElement('section');
    card.className = 'seven-star-card';
    const title = document.createElement('strong');
    title.textContent = traditionalize(label);
    const resultText = document.createElement('span');
    resultText.className = 'seven-star-card-value';
    resultText.textContent = traditionalize(value);
    const note = document.createElement('small');
    note.textContent = traditionalize(detail);
    card.append(title, resultText, note);
    cards.append(card);
  };
  if (selectedObjectives.has('longevity')) {
    const candidates = objectiveCandidates.longevity;
    addCard('延寿', candidates.length ? candidateLabels(candidates) : '无', candidates.length ? `同宫格局：${candidateFormations(candidates)}；日干甲` : '当前时辰未满足值符、天心、生门、乙丙丁及日干甲同宫条件');
  }
  if (selectedObjectives.has('career')) {
    const candidates = objectiveCandidates.career;
    addCard('事业', candidates.length ? candidateLabels(candidates) : '无', candidates.length ? `同宫格局：${candidateFormations(candidates)}` : '当前时辰未满足事业目标的八神、九星、八门、天盘干及格局条件');
  }
  if (selectedObjectives.has('wealth')) {
    const candidates = objectiveCandidates.wealth;
    addCard('财富', candidates.length ? candidateLabels(candidates) : '无', candidates.length ? `同宫格局：${candidateFormations(candidates)}` : '当前时辰未满足财富目标的八神、九星、八门、天盘干及格局条件');
  }
  container.append(cards);
}

function makeLayer(className, label, value) {
  const row = document.createElement('div');
  row.className = `layer ${className}`;
  const name = document.createElement('span');
  name.textContent = traditionalize(value);
  const caption = document.createElement('span');
  caption.className = 'layer-label';
  caption.textContent = traditionalize(label);
  row.append(name, caption);
  return row;
}

function getVoidBranches(pillar) {
  const cycleIndex = GANZHI_CYCLE.indexOf(pillar || '');
  if (cycleIndex < 0) return [];

  const xunStart = Math.floor(cycleIndex / 10) * 10;
  const occupiedBranches = new Set(GANZHI_CYCLE.slice(xunStart, xunStart + 10).map((ganzhi) => ganzhi[1]));
  return CYCLE_BRANCHES.map(([branch]) => branch).filter((branch) => !occupiedBranches.has(branch));
}

function findPalaceIndex(chart, field, value) {
  return chart[field]?.findIndex((item) => simplify(item) === value) ?? -1;
}

function getSevenStarFormationNames(chart, index) {
  const door = simplify(chart.天門?.[index]);
  const skyStem = simplify(chart.天盤?.[index]);
  const earthStem = simplify(chart.地盤?.[index]);
  const names = [];
  if (door === simplify(chart.值使) && earthStem === '丁') names.push('玉女守门');
  if (skyStem === '戊' && earthStem === '乙') names.push('青龙返首');
  if (skyStem === '丙' && earthStem === '戊') names.push('飞鸟跌穴');
  return names;
}

function getSevenStarObjectiveCandidates(chart, objective) {
  const criteria = {
    longevity: {
      gods: ['值符'], stars: ['天心'], doors: ['生门'], skyStems: ['乙', '丙', '丁'],
      formations: ['玉女守门', '青龙返首', '飞鸟跌穴'], dayStem: '甲',
    },
    career: {
      gods: ['值符', '六合', '九地'], stars: ['天心', '天任', '天芮'], doors: ['生门', '开门'], skyStems: ['乙', '丙', '丁', '戊'],
      formations: ['玉女守门', '青龙返首', '飞鸟跌穴'],
    },
    wealth: {
      gods: ['值符', '九天', '九地'], stars: ['天心', '天任'], doors: ['生门'], skyStems: ['乙', '丙', '丁', '戊'],
      formations: ['玉女守门', '青龙返首', '飞鸟跌穴'],
    },
  }[objective];
  if (!criteria) return [];
  if (criteria.dayStem && simplify(chart.日柱?.[0]) !== criteria.dayStem) return [];

  return PALACES.reduce((candidates, _, index) => {
    const god = simplify(chart.八神?.[index]);
    const star = simplify(chart.九星?.[index]);
    const door = simplify(chart.天門?.[index]);
    const skyStem = simplify(chart.天盤?.[index]);
    const formations = getSevenStarFormationNames(chart, index);
    const hasFormation = formations.some((formation) => criteria.formations.includes(formation));
    if (criteria.gods.includes(god)
      && criteria.stars.includes(star)
      && criteria.doors.includes(door)
      && criteria.skyStems.includes(skyStem)
      && hasFormation) {
      candidates.push({ index, formations });
    }
    return candidates;
  }, []);
}

async function findMonthlyTravelDates(monthValue, hour, natalChart) {
  const [year, month] = monthValue.split('-').map(Number);
  const dayCount = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
  const natalTargets = {
    valueFu: findPalaceIndex(natalChart, '八神', '值符'),
    nineHeaven: findPalaceIndex(natalChart, '八神', '九天'),
    lifeDoor: findPalaceIndex(natalChart, '天門', '生门'),
  };
  const matches = [];

  if (Object.values(natalTargets).some((index) => index < 0)) return matches;

  for (let day = 1; day <= dayCount; day += 1) {
    const baseDatetime = `${year}${pad(month)}${pad(day)}${pad(hour)}`;
    const monthChart = await generateByChartType('yuejia', baseDatetime);
    const dayChart = await generateByChartType('rijia', baseDatetime);
    const monthLifeDoor = findPalaceIndex(monthChart, '天門', '生门');
    const monthValueFu = findPalaceIndex(monthChart, '八神', '值符');
    const monthNineHeaven = findPalaceIndex(monthChart, '八神', '九天');
    const dayValueFu = findPalaceIndex(dayChart, '八神', '值符');
    const dayNineHeaven = findPalaceIndex(dayChart, '八神', '九天');
    const dayLifeDoor = findPalaceIndex(dayChart, '天門', '生门');
    const categories = [
      {
        targetIndex: natalTargets.valueFu,
        dayMatches: dayNineHeaven === natalTargets.valueFu,
        monthMatches: monthLifeDoor === natalTargets.valueFu,
        timeField: '八神',
        timeValue: '值符',
        detail: '月盘生门与日盘九天同临本命值符宫',
      },
      {
        targetIndex: natalTargets.nineHeaven,
        dayMatches: dayLifeDoor === natalTargets.nineHeaven,
        monthMatches: monthValueFu === natalTargets.nineHeaven,
        timeField: '八神',
        timeValue: '九天',
        detail: '月盘值符与日盘生门同临本命九天宫',
      },
      {
        targetIndex: natalTargets.lifeDoor,
        dayMatches: dayValueFu === natalTargets.lifeDoor,
        monthMatches: monthNineHeaven === natalTargets.lifeDoor,
        timeField: '天門',
        timeValue: '生门',
        detail: '月盘九天与日盘值符同临本命生门宫',
      },
    ];

    for (const category of categories) {
      category.hours = [];
      if (!category.dayMatches) {
        category.matches = false;
        category.calendarLabel = category.monthMatches ? '月日時' : '日時';
        continue;
      }

      for (let slot = 0; slot < 12; slot += 1) {
        const centerHour = (slot + 1) * 2 % 24;
        const startHour = (centerHour + 23) % 24;
        const endHour = (centerHour + 1) % 24;
        const timeDatetime = `${year}${pad(month)}${pad(day)}${pad(centerHour)}`;
        const timeChart = window.Qimen.chartToObject(window.Qimen.generateChartByDatetime(timeDatetime, {
          定局法: methodInput.value,
          夜子時: ziMethodInput.value,
        }));
        if (findPalaceIndex(timeChart, category.timeField, category.timeValue) === category.targetIndex) {
          category.hours.push(`${pad(startHour)}:00–${pad(endHour)}:00${centerHour === 0 ? '＊' : ''}`);
        }
      }
      category.matches = category.hours.length > 0;
      category.calendarLabel = category.monthMatches ? '月日時' : '日時';
    }

    if (categories.some(({ matches: categoryMatches }) => categoryMatches)) {
      matches.push({
        day,
        weekday: weekdays[new Date(Date.UTC(year, month - 1, day)).getUTCDay()],
        categories,
      });
    }
  }

  return matches;
}

function getPalaceMarkers(chart) {
  const markers = PALACES.map(() => []);
  const addMarker = (index, text, title, type) => {
    if (index < 0 || markers[index].some((marker) => marker.text === text)) return;
    markers[index].push({ text, title, type });
  };

  const voidSources = chart.盤型 === '命盘'
    ? [['时旬空', chart.時柱]]
    : chart.盤型 === '年盘'
      ? [['年旬空', chart.年柱]]
      : chart.盤型 === '月盘'
        ? [['月旬空', chart.月柱]]
        : chart.盤型 === '日盘'
          ? [['日旬空', chart.日柱]]
          : [['日旬空', chart.日柱], ['时旬空', chart.時柱]];
  voidSources.forEach(([label, pillar]) => {
    const branches = getVoidBranches(pillar);
    branches.forEach((branch) => {
      const index = PALACES.findIndex(({ number }) => Number(number) === VOID_BRANCH_PALACES[branch]);
      const detail = `${label}：${branches.join('、')}`;
      const markerLabel = chart.盤型 === '时盘' ? `${label.replace('旬空', '')}空亡` : '空亡';
      addMarker(index, markerLabel, detail, 'void');
    });
  });
  const dayBranch = chart.日柱?.slice(-1);
  const yimaBranch = YIMA_BRANCHES[dayBranch];
  const yimaPalaceNumber = VOID_BRANCH_PALACES[yimaBranch];
  const yimaIndex = PALACES.findIndex(({ number }) => Number(number) === yimaPalaceNumber);
  if (yimaIndex >= 0) {
    const yimaPalace = PALACES[yimaIndex];
    addMarker(yimaIndex, '驿马', `${yimaPalace.direction}${yimaPalace.name}：日支${dayBranch}，驿马在${yimaBranch}`, 'auspicious');
  }
  PALACES.forEach((palace, index) => {
    const door = simplify(chart.天門?.[index]);
    const skyStem = simplify(chart.天盤?.[index]);
    const earthStem = simplify(chart.地盤?.[index]);
    const god = simplify(chart.八神?.[index]);
    const palaceNumber = Number(palace.number);

    if (STEM_TOMB_PALACES[skyStem] === palaceNumber) {
      addMarker(index, '入墓', `天盤${skyStem}落${palace.direction}${palace.name}，為${skyStem}入墓`, 'overcoming');
    }

    if (skyStem === '乙' && earthStem === '庚') {
      addMarker(index, '日奇被刑', '天盤乙加地盤庚', 'overcoming');
    }
    if (skyStem === '戊' && earthStem === '戊') {
      addMarker(index, '青龍伏吟', '天盤戊加地盤戊', 'overcoming');
    }

    const controlledWonders = {
      乙: [6, 7],
      丙: [1],
      丁: [1],
    };
    const overcomingStems = {
      乙: ['庚', '辛'],
      丙: ['壬', '癸'],
      丁: ['壬', '癸'],
    };
    if (controlledWonders[skyStem]?.includes(palaceNumber) || overcomingStems[skyStem]?.includes(earthStem)) {
      const causes = [];
      if (controlledWonders[skyStem]?.includes(palaceNumber)) causes.push(`${PALACE_NAMES[palaceNumber]}宮克${skyStem}奇`);
      if (overcomingStems[skyStem]?.includes(earthStem)) causes.push(`地盤${earthStem}克${skyStem}奇`);
      addMarker(index, '三奇受制', causes.join('；'), 'overcoming');
    }

    const risingPalace = { 乙: 3, 丙: 9, 丁: 7 }[skyStem];
    if (risingPalace === palaceNumber) {
      addMarker(index, '三奇升殿', `天盤${skyStem}奇臨${PALACE_NAMES[palaceNumber]}宮`, 'auspicious');
    }
    if (skyStem === '丁' && earthStem === '丁') {
      addMarker(index, '奇入太陰', '天盤丁加地盤丁', 'auspicious');
    }

    const qiyiPairs = {
      乙庚: '乙庚奇合', 庚乙: '乙庚奇合',
      丙辛: '丙辛奇合', 辛丙: '丙辛奇合',
      丁壬: '丁壬奇合', 壬丁: '丁壬奇合',
      戊癸: '戊癸儀合', 癸戊: '戊癸儀合',
      甲己: '甲己儀合', 己甲: '甲己儀合',
    };
    const qiyiPair = qiyiPairs[`${skyStem}${earthStem}`];
    if (qiyiPair) addMarker(index, '奇儀相合', qiyiPair, 'auspicious');

    const disguisedFormations = [
      { name: '天假', door: '景门', stems: ['乙', '丙', '丁'], gods: ['九天'] },
      { name: '地假', door: '杜门', stems: ['丁', '己', '癸'], gods: ['九地', '六合', '太阴'] },
      { name: '人假', door: '景门', stems: ['壬'], gods: ['九天'] },
      { name: '神假', door: '伤门', stems: ['丁', '己', '癸'], gods: ['九地'] },
      { name: '鬼假', door: '死门', stems: ['丁', '己', '癸'], gods: ['九地'] },
    ];
    disguisedFormations.forEach((formation) => {
      if (door === formation.door && formation.stems.includes(skyStem) && formation.gods.includes(god)) {
        addMarker(index, formation.name, `${formation.door}、天盤${skyStem}、${god}同宮`, 'auspicious');
      }
    });

    if (skyStem === '丙' && door === '生门' && god === '九天') {
      addMarker(index, '神遁', '天盤丙、九天、生門同宮', 'auspicious');
    }
    if (skyStem === '乙' && ['休门', '生门', '开门'].includes(door)
      && (Number(palace.number) === 1 || earthStem === '癸')) {
      addMarker(index, '龍遁', '天盤乙會休、生、開吉門，落坎宮或下臨地盤癸', 'auspicious');
    }
  });

  const patterns = window.Qimen?.detectPatterns?.(chart) || [];
  patterns.filter((item) => item.宮 && item.格).forEach((item) => {
    const palaceNumber = Object.entries(PALACE_NAMES)
      .find(([, name]) => simplify(name) === simplify(item.宮))?.[0];
    const index = PALACES.findIndex(({ number }) => Number(number) === Number(palaceNumber));
    const relation = simplify(item.關係);
    const text = item.格 === '門迫' ? '門克宮'
      : item.格 === '宮迫' ? '宮克門'
        : relation === '宫生门' ? '宮生門'
          : relation === '门生宫' ? '門生宮'
            : item.格;
    const type = item.格 === '門迫' || item.格 === '宮迫' ? 'overcoming' : 'pattern';
    addMarker(index, text, item.細節 || item.格, type);
  });

  return markers;
}

function renderPalaces(chart) {
  const grid = document.querySelector('#chart-grid');
  grid.replaceChildren();
  const palaceMarkers = getPalaceMarkers(chart);

  PALACES.forEach((palace, index) => {
    const cell = document.createElement('article');
    cell.className = `palace${index === 4 ? ' center' : ''}`;
    const head = document.createElement('div');
    head.className = 'palace-head';
    head.dataset.gua = ({ 1: '☵', 2: '☷', 3: '☳', 4: '☴', 5: '中', 6: '☰', 7: '☱', 8: '☶', 9: '☲' })[palace.number];
    head.title = traditionalize(`${palace.name}卦象`);
    const direction = document.createElement('span');
    direction.textContent = traditionalize(palace.direction);
    const number = document.createElement('span');
    number.textContent = palace.number;
    head.append(direction, number);

    const name = document.createElement('div');
    name.className = 'palace-name';
    name.textContent = traditionalize(palace.name);
    const layers = document.createElement('div');
    layers.className = 'palace-layers';
    layers.append(
      makeLayer('god', '神', chart.八神?.[index]),
      makeLayer('star', '星', chart.九星?.[index]),
      makeLayer('door', '门', chart.天門?.[index]),
      makeLayer('heaven', '天', chart.天盤?.[index]),
      makeLayer('earth', '地', chart.地盤?.[index]),
    );
    const markers = document.createElement('div');
    markers.className = 'palace-markers';
    palaceMarkers[index].forEach((marker) => {
      const badge = document.createElement('span');
      badge.className = `palace-marker ${marker.type}`;
      badge.textContent = traditionalize(marker.text);
      badge.title = traditionalize(marker.title);
      markers.append(badge);
    });
    cell.append(head, name, layers, markers);
    grid.append(cell);
  });
}

function renderFlightCharts(charts) {
  const container = document.querySelector('#flight-grid');
  container.replaceChildren();

  charts.forEach((chart) => {
    const panel = document.createElement('section');
    panel.className = 'flight-panel';
    const panelHeading = document.createElement('div');
    panelHeading.className = 'flight-panel-heading';
    const title = document.createElement('span');
    title.className = 'flight-panel-title';
    title.textContent = traditionalize(chart.盤型);
    const meta = document.createElement('span');
    meta.className = 'flight-panel-meta';
    meta.textContent = traditionalize(`中宮${FLYING_STAR_NAMES[chart.中宮]} · ${chart.飛向}`);
    panelHeading.append(title, meta);

    const grid = document.createElement('div');
    grid.className = 'flight-palace-grid';
    PALACES.forEach((palace, index) => {
      const cell = document.createElement('div');
      cell.className = `flight-palace${index === 4 ? ' center' : ''}`;
      const heading = document.createElement('div');
      heading.className = 'flight-palace-header';
      const gua = document.createElement('span');
      gua.className = 'flight-gua';
      gua.textContent = palace.number === '5' ? '中' : ({ 1: '☵', 2: '☷', 3: '☳', 4: '☴', 6: '☰', 7: '☱', 8: '☶', 9: '☲' })[palace.number];
      const number = document.createElement('span');
      number.textContent = palace.number;
      heading.append(gua, number);
      const name = document.createElement('div');
      name.className = 'flight-palace-name';
      name.textContent = traditionalize(palace.name);
      const star = document.createElement('div');
      star.className = `flight-star-value${[1, 6, 8, 9].includes(chart.九宮星[index]) ? ' highlighted' : ''}`;
      star.textContent = chart.九宮星[index];
      const starName = document.createElement('div');
      starName.className = 'flight-star-name';
      starName.textContent = traditionalize(FLYING_STAR_NAMES[chart.九宮星[index]]);
      cell.append(heading, name, star, starName);
      grid.append(cell);
    });
    panel.append(panelHeading, grid);
    container.append(panel);
  });
}

function getValueDoorPalaceLabel(chart) {
  const valueDoor = simplify(chart.值使);
  const index = chart.天門?.findIndex((door) => simplify(door) === valueDoor) ?? -1;
  const palace = PALACES[index];
  if (palace) return palace.number === '5' ? palace.name : `${palace.direction}${palace.name}`;
  return chart.值使落宮 || '—';
}

function renderHub(chart) {
  const container = document.querySelector('#hub-list');
  container.replaceChildren();
  [
    ['旬首', chart.旬首],
    ['符首', chart.符首],
    ['值符', `${chart.值符 || '—'}${chart.值符落宮 ? ` · ${chart.值符落宮}` : ''}`],
    ['值使', `${chart.值使 || '—'} · ${getValueDoorPalaceLabel(chart)}`],
  ].forEach(([label, value]) => {
    const item = document.createElement('div');
    item.className = 'hub-item';
    const title = document.createElement('span');
    title.className = 'hub-label';
    title.textContent = traditionalize(label);
    const content = document.createElement('span');
    content.className = 'hub-value';
    content.textContent = traditionalize(value);
    item.append(title, content);
    container.append(item);
  });
}

function renderInsights(chart) {
  const container = document.querySelector('#formation-list');
  container.replaceChildren();
  const formations = chart.格局列表 || [];
  container.closest('.insight-block').hidden = formations.length === 0;

  if (formations.length > 0) {
    formations.forEach((formation) => {
      const chip = document.createElement('span');
      chip.className = 'formation-chip';
      if (formation.吉凶) chip.dataset.luck = formation.吉凶;
      chip.title = traditionalize(formation.細節 || formation.格);
      const name = document.createElement('span');
      name.textContent = traditionalize(formation.格);
      chip.append(name);
      if (formation.讀法) {
        const reading = document.createElement('span');
        reading.className = 'formation-reading';
        reading.textContent = traditionalize(formation.讀法.split('（')[0]);
        chip.append(reading);
      }
      if (formation.宮) {
        const place = document.createElement('span');
        place.className = 'formation-place';
        place.textContent = traditionalize(`${formation.宮}宫`);
        chip.append(place);
      }
      container.append(chip);
    });
  }

  document.querySelector('#tianyi-value').textContent = traditionalize(chart.天乙 || '—');
}

function renderChart(chart, datetime, lunarDate) {
  const year = datetime.slice(0, 4);
  const month = Number(datetime.slice(4, 6));
  const day = Number(datetime.slice(6, 8));
  const hour = Number(datetime.slice(8, 10));
  const dateLabel = chart.盤型 === '年盘'
    ? `${year} 年 · 年家盘`
    : chart.盤型 === '月盘'
      ? `${year} 年 ${month} 月 · 月家盘（${chart.月柱 || '节气月'}）`
      : chart.盤型 === '日盘'
        ? `${year} 年 ${month} 月 ${day} 日 · 日家盘`
        : `${year} 年 ${month} 月 ${day} 日 · ${hourLabel(hour)}`;
  document.querySelector('#chart-date-label').textContent = traditionalize(dateLabel);
  const lunarLabel = document.querySelector('#lunar-date-label');
  lunarLabel.textContent = traditionalize(lunarDate);
  lunarLabel.hidden = false;
  document.querySelector('#result-eyebrow').textContent = traditionalize(`${chart.節氣 || chart.盤型 || '时盘'} · ${chart.三元 || '三元未明'}`);
  document.querySelector('#result-title').textContent = traditionalize(`${chart.陰陽 || ''}遁${chart.局數 || ''}局`);
  document.querySelector('#method-tag').textContent = traditionalize(chart.盤型 || `${chart.定局法 || methodInput.value}法`);
  document.querySelector('#plate-stamp').textContent = traditionalize(chart.盤型 === '命盘' ? '生辰 · 时家转盘' : `${chart.盤型 || '时盘'} · 转盘`);

  const pillars = document.querySelector('#pillars');
  pillars.replaceChildren(
    makePillar('年柱', chart.年柱),
    makePillar('月柱', chart.月柱),
    makePillar('日柱', chart.日柱),
    makePillar('时柱', chart.時柱),
  );
  renderPalaces(chart);
  renderSevenStarLamp(chart);
  renderHub(chart);
  renderInsights(chart);
  document.querySelector('#source-note').textContent = traditionalize(chart.展示說明 || '时家盘由 qimen-dunjia 计算库生成；时刻按 UTC+8 标准时解释，子时可切换换日口径。');
  if (chart.落於夜子時) {
    document.querySelector('#zi-method').setAttribute('aria-description', `当前选择：日柱算${chart.夜子時}`);
  }
  errorMessage.hidden = true;
  emptyState.hidden = true;
  result.hidden = false;
}

async function generateChart(event) {
  event?.preventDefault();
  errorMessage.hidden = true;

  if (!dateInput.value) {
    errorMessage.textContent = traditionalize('请先选择公历日期。');
    errorMessage.hidden = false;
    return;
  }
  if (!window.Qimen?.generateChartByDatetime || !window.Qimen?.chartToObject) {
    errorMessage.textContent = traditionalize('排盘引擎未能载入。请检查网络连接后刷新页面。');
    errorMessage.hidden = false;
    return;
  }

  const [year, month, day] = dateInput.value.split('-');
  const chartType = chartTypeInput.value;
  const selectedHour = Number(hourInput.value);
  const datetime = `${year}${month}${day}${pad(selectedHour)}`;
  const usesMonthlyScan = chartType === 'mingpan' && (travelInput.checked || personalThreeVictoryInput.checked);
  const scanMonth = usesMonthlyScan ? travelMonthInput.value : '';
  if (usesMonthlyScan && hasGeneratedNatalChart && !scanMonth) {
    errorMessage.textContent = traditionalize('请选择要扫描的月份。');
    errorMessage.hidden = false;
    return;
  }

  try {
    await loadTraditionalizer();
    const chart = await generateByChartType(chartType, datetime);
    const lunarDate = await formatLunarDate(datetime, chart);
    renderChart(chart, datetime, lunarDate);
    hasGeneratedNatalChart = chartType === 'mingpan';
    updateChartTypeControls();
    const monthlyMatches = scanMonth ? await findMonthlyTravelDates(scanMonth, selectedHour, chart) : [];
    renderTravelMonth(scanMonth, monthlyMatches, personalThreeVictoryInput.checked ? 'personalThreeVictory' : 'travel');
    const flightCharts = await generateFlightCharts(datetime);
    renderFlightCharts(flightCharts);
  } catch (error) {
    errorMessage.textContent = traditionalize(error instanceof Error ? error.message : '起盘失败，请检查输入。');
    errorMessage.hidden = false;
    result.hidden = true;
    emptyState.hidden = true;
  }
}

populateHours();
setDefaults();
travelMonthInput.value = dateInput.value.slice(0, 7);
form.addEventListener('submit', generateChart);
chartTypeInput.addEventListener('change', () => {
  updateChartTypeControls();
  document.querySelector('#travel-month-section').hidden = true;
  document.querySelector('#seven-star-section').hidden = true;
});
sevenStarInput.addEventListener('change', () => {
  updateChartTypeControls();
  document.querySelector('#seven-star-section').hidden = true;
  if (chartTypeInput.value === 'shijia') generateChart();
});
document.querySelectorAll('input[name="sevenStarObjective"]').forEach((input) => {
  input.addEventListener('change', () => {
    if (chartTypeInput.value === 'shijia' && sevenStarInput.checked) generateChart();
  });
});
travelInput.addEventListener('change', () => {
  updateChartTypeControls();
  document.querySelector('#travel-month-section').hidden = true;
  document.querySelector('#seven-star-section').hidden = true;
  if (hasGeneratedNatalChart) generateChart();
});
personalThreeVictoryInput.addEventListener('change', () => {
  updateChartTypeControls();
  document.querySelector('#travel-month-section').hidden = true;
  if (hasGeneratedNatalChart) generateChart();
});
travelMonthInput.addEventListener('change', () => {
  if (chartTypeInput.value === 'mingpan'
    && (travelInput.checked || personalThreeVictoryInput.checked)
    && hasGeneratedNatalChart) generateChart();
});
shiftInput.addEventListener('change', () => {
  updateChartTypeControls();
  document.querySelector('#travel-month-section').hidden = true;
});
shiftStepsInput.addEventListener('change', () => {
  document.querySelector('#travel-month-section').hidden = true;
  shiftStepStatus.textContent = traditionalize(shiftStepLabel(shiftStepsInput.value));
});
function shiftSelectedPalace(direction) {
  if (!hasGeneratedNatalChart) return;
  const currentSteps = Number(shiftStepsInput.value);
  const nextSteps = (currentSteps + direction + 9) % 9;
  shiftStepsInput.value = String(nextSteps);
  generateChart();
}

previousShiftButton.addEventListener('click', () => shiftSelectedPalace(-1));
nextShiftButton.addEventListener('click', () => shiftSelectedPalace(1));
updateChartTypeControls();
loadTraditionalizer();
document.querySelector('#now-button').addEventListener('click', () => {
  setDefaults();
  generateChart();
});
document.querySelector('#clear-button').addEventListener('click', () => {
  form.reset();
  setDefaults();
  travelMonthInput.value = dateInput.value.slice(0, 7);
  hasGeneratedNatalChart = false;
  errorMessage.hidden = true;
  result.hidden = true;
  emptyState.hidden = false;
  document.querySelector('#chart-date-label').textContent = traditionalize('等待起盘');
  document.querySelector('#lunar-date-label').hidden = true;
  document.querySelector('#plate-stamp').textContent = traditionalize('时家 · 转盘');
  document.querySelector('#travel-month-section').hidden = true;
  document.querySelector('#seven-star-section').hidden = true;
  document.querySelector('#shift-step-status').textContent = traditionalize('尚未生成命盘');
  document.querySelector('#flight-grid').replaceChildren();
  updateChartTypeControls();
});
document.querySelector('#previous-date-button').addEventListener('click', () => shiftSelectedDate(-1));
document.querySelector('#next-date-button').addEventListener('click', () => shiftSelectedDate(1));
function shiftSelectedShichen(direction) {
  const currentHour = Number(hourInput.value);
  const currentBranch = branchForHour(currentHour);
  const branchIndex = BRANCHES.findIndex(([branch]) => branch === currentBranch);
  if (branchIndex < 0) return;

  let nextHour;
  let dayOffset = 0;

  if (direction > 0 && currentBranch === '子') {
    nextHour = 1;
    if (currentHour === 23) dayOffset = 1;
  } else if (direction > 0 && currentBranch === '亥') {
    nextHour = 23;
  } else if (direction < 0 && currentBranch === '子') {
    nextHour = 21;
    if (currentHour === 0) dayOffset = -1;
  } else if (direction > 0) {
    nextHour = BRANCHES[branchIndex + 1][1];
  } else {
    nextHour = BRANCHES[branchIndex - 1][1];
  }

  if (dayOffset && !setSelectedDateOffset(dayOffset)) return;

  hourInput.value = String(nextHour);
  generateChart();
}

document.querySelector('#previous-shichen-button').addEventListener('click', () => shiftSelectedShichen(-1));
document.querySelector('#next-shichen-button').addEventListener('click', () => shiftSelectedShichen(1));

if (window.Qimen?.generateChartByDatetime) {
  engineStatus.textContent = traditionalize('排盘引擎已就绪');
  engineStatus.dataset.state = 'ready';
} else {
  engineStatus.textContent = traditionalize('排盘引擎连接中断');
  engineStatus.dataset.state = 'error';
}
